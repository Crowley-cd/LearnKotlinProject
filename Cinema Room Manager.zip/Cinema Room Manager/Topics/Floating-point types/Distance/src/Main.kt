fun main() {
    val a = readln().toInt()
    val b = readln().toInt()
    val c: Double = a.toDouble() / b
    println(c)
}
