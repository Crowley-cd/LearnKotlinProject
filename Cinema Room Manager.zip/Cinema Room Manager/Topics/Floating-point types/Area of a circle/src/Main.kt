fun main() {
    val r = readln().toInt()
    val s = 3.1415 * r * r.toDouble()
    println(s)
}
