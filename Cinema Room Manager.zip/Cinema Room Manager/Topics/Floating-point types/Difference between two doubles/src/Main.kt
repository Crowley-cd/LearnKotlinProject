import kotlin.math.abs

fun main() {
    val a = readln().toDouble()
    val b = readln().toDouble()
    val c = b - a
    println(c)
 }