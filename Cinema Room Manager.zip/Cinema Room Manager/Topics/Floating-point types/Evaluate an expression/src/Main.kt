fun main() {
    val a = readln().toDouble()
    val b = readln().toDouble()
    val c = readln().toDouble()
    val d = readln().toDouble()
    println(a * 10.5 + b * 4.4 + (c + d) / 2.2)
}