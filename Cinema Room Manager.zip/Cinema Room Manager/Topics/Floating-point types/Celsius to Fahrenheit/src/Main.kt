fun main() {
    val celsius = readln().toDouble()
    val fahrenheit = celsius * 1.8 + 32
    println(fahrenheit)
}
