fun main() {
    val p = readln().toDouble()
    val h = readln().toDouble()
    val ph = p * h * 9.8
    println(ph)
}