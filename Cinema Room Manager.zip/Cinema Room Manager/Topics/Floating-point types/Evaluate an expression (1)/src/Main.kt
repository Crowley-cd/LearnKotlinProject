fun main() {
    val x = readln().toDouble()
    println(x * x * x + x * x + x + 1)
}
