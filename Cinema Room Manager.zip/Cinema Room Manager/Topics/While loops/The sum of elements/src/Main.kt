fun main() {
    var sum = 0
    var ent = 10

    while (ent != 0) {
        ent = readln().toInt()
        sum += ent
    }
    println("$sum")
}