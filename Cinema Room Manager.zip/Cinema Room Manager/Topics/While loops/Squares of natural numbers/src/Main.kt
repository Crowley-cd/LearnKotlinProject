import kotlin.math.absoluteValue

fun main() {
    val ent = readln().toInt()
    var n = 0
    if (ent > 0) {
        n = 1
        while (ent.absoluteValue >= n * n) {
            println(n * n)
            n++
        }
    } 
}
