fun main() {
    var a = 1
    var length = 0
    while (a != 0) {
        a = readln().toInt()
        length ++
    }
    println(length - 1)
}
