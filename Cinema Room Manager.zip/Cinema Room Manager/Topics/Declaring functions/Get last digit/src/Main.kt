import kotlin.math.abs

fun getLastDigit(a: Int): Int = abs(a) % 10

/* Do not change code below */
fun main() {
    val a = readLine()!!.toInt()
    println(getLastDigit(a))
}

//fun abs(a: Int): Int = abs(a)