fun isVowel(whether: Char): Boolean {
    var botype = false
    val letterlist = listOf<Char>('a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U')
    if (whether in letterlist) botype = true
        return botype
}
fun main() {
    val letter = readLine()!!.first()

    println(isVowel(letter))
}
