fun main() {
    val a = readln().toInt()
    var b = 0
    var sum = 0
    for (i in 1..a) {
        b = readln().toInt()
        sum += b
    }
    println(sum)
}