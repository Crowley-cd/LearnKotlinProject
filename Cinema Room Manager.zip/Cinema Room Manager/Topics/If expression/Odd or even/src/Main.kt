fun main() {
    val a = readln().toInt()
    if (a % 2 == 0) println("EVEN") else println("ODD")
}