fun main() {

    val a = readLine()!!.toInt()
    val b = readLine()!!.toInt()

    if (a > b) println(a)
    if (a < b) println(b)
    if (a == b) println(b)
}