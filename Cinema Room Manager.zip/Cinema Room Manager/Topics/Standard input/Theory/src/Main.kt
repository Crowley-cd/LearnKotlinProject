// You can experiment here, it won’t be checked

fun main(){
    for ( i in 1..10) {
        println("hello")}
}
