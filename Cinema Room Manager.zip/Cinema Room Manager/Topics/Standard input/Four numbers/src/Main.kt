import java.util.Scanner

fun main() {
    val scanner = Scanner(System.`in`)
    val a = scanner.next()
    val b = scanner.next()
    val c = scanner.next()
    val d  = scanner.next()
    println(a)
    println(b)
    println(c)
    println(d)
}
