fun main() {
    val a: Int = readln().toInt()
    println(a / 100 + a % 10 + a % 100 / 10)
}
