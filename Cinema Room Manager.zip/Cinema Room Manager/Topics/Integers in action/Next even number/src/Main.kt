fun main() {
    val num: Int = readln().toInt()
    val ost = num % 2
    if (ost == 0) {
        println(num + 2) 
    } else {
        println(num + 1) 
    }

}
