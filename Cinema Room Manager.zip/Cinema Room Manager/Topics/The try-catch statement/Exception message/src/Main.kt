// ...
try {
    problemFunction()
} catch (e: Exception) {
    println(e.message)
} 
// ...