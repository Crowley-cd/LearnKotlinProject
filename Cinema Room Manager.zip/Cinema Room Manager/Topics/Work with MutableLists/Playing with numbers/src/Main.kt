fun main() {
    val numbers = readLine()!!.split(' ').map{it.toInt()}.toMutableList()
    // do not touch the lines above
    numbers.add(0, numbers.sum())
    numbers.removeAt(numbers.size - 2)// write your code here   

    // do not touch the lines below
    println(numbers.joinToString(" "))
}
