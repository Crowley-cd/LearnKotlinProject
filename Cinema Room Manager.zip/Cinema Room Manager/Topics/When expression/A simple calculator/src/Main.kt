fun main() {
    val (a, op, b) = readln().split(" ")
    println(
        when {
        a.toString() == "0" -> "Division by 0!"
        b.toString() == "0" -> "Division by 0!"
        op == "+" -> a.toLong() + b.toLong()
        op == "-" -> a.toLong() - b.toLong()
        op == "/" -> a.toLong() / b.toLong()
        op == "*" -> a.toLong() * b.toLong()
        else -> "Unknown operator"
    }
    )
}
