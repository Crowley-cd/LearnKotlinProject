fun main() {
    val a: String = readln()
    println(a.toString().toBoolean())
}