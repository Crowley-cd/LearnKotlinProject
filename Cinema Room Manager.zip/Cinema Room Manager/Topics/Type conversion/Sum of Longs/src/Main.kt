fun main() {
    val a = "32"
    println(a.toChar())
}