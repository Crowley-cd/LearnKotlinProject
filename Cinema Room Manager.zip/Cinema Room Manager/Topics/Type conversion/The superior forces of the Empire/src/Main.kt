fun main() {
    val a:String = readln()
    val b:String = readln()
    println(a.toInt() / b.toInt())
}