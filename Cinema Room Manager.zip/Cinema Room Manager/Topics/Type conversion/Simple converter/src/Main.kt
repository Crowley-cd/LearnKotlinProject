fun main() {
    val enter: String = readln()
    println(enter.toInt())
    println(enter.toDouble())
    println(enter.toString().toBoolean())


}