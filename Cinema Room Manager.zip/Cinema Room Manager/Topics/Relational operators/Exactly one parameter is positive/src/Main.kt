fun main() {
    val a = readln().toInt()
    val b = readln().toInt()
    val c = readln().toInt()
    var result: Int = 0
    if (a > 0) {
        result ++
    }
    if (b > 0) {
        result ++
    }
    if (c > 0) {
        result ++
    }

    when (result) {
        1 -> println(true)
        in 2..Int.MAX_VALUE -> println(false)
        0 -> println(false)
        else -> println(true)
    }
}
