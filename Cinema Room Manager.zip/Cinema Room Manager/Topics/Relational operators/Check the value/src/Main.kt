fun main() {
    val a = readln().toInt()
    if (a < 10) { println(true) } else { println(false) }
}
