fun main() {
    val nuts = readln().toInt()
    val weekend = readln().toBoolean()
    when {
        nuts >= 10 && nuts <= 20 && weekend == false -> println(true)
        nuts >= 15 && nuts <= 25 && weekend == true -> println(true)
        else -> println(false)
    }
}
