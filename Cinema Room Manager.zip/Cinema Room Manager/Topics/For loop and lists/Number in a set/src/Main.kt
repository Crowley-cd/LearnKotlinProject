fun main() {
    val N = readln().toInt()
    val list = mutableListOf<Int>()
    repeat(N) {
        list.add(readln().toInt())
    }
    val M = readln().toInt()
    if (M in list) println("YES") else println("NO")
}