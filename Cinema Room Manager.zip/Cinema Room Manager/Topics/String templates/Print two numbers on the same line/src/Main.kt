fun main() {
    val firstval: Int = readln().toInt()
    val secval: Int = readln().toInt()
    println("$firstval $secval")
}
