fun main() {
    val str: String = readln()
    println("${str.length} repetitions of the word $str: ${str.repeat(str.length)}")
}