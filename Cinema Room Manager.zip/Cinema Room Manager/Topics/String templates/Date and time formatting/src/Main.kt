fun main() {
    val (a, b, c) = readln().split(" ")
    val (d, e, f) = readln().split(" ")
    println("$a:$b:$c $d/$e/$f")
}
